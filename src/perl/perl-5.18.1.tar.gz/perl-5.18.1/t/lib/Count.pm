# zero! ha ha ha
package Count;
"ha!";
__DATA__
one! ha ha ha
two! ha ha ha
three! ha ha ha
four! ha ha ha
