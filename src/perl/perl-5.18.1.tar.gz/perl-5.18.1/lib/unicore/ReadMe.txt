# Date: 2012-09-24, 22:40:00 GMT [KW]
#
# Unicode Character Database
# Copyright (c) 1991-2012 Unicode, Inc.
# For terms of use, see http://www.unicode.org/terms_of_use.html
#
# For documentation, see NamesList.html,
# UAX #38, "Unicode Han Database (Unihan)," and
# UAX #44, "Unicode Character Database."
#

This directory contains final data files
for the Unicode Character Database (UCD) for Unicode 6.2.0.


